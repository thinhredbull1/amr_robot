#! /usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist,Pose
import dynamic_reconfigure
import math
from math import atan2
from ar_track_alvar_msgs.msg import AlvarMarker,AlvarMarkers
from dynamic_reconfigure.server import Server
from move_to_point.cfg import pidConfig
WAIT_TO_YAW=0
WAIT_TO_Y=2
MOVE_ALL_AXIS=1
def quaternion_to_euler(x, y, z, w):
    """
    Convert a quaternion to Euler angles (roll, pitch, yaw).
    
    Parameters:
    x, y, z, w - Quaternion components
    
    Returns:
    roll, pitch, yaw - Euler angles in radians
    """
    
    # Roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    
    # Pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    if abs(sinp) >= 1:
        pitch = math.copysign(math.pi / 2, sinp)  # use 90 degrees if out of range
    else:
        pitch = math.asin(sinp)
    
    # Yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    
    return roll, pitch, yaw
class Robot_Controller:
    def __init__(self):
        rospy.init_node('docking_ar')
        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('/ar_pose_marker',AlvarMarkers,self.pos_callback)
        self.velocity_msg = Twist()
        self.angular_p = 0
        self.linear_p =0
        self.angular_d =0
        self.linear_d = 0
        self.ar_pos=Pose()
        self.state_target=[0,0,0]
        self.speed_cmd=[0,0,0]
        self.last_e=[0,0,0]
        self.id = None
        self.lt = ""
        self.at = ""
        self.last_stop=0
        self.first_config=0
        self.finish_docking=True
        self.docking_state=MOVE_ALL_AXIS
        self.linear_p = rospy.get_param('~linear_p', 0.5)
        self.linear_d = rospy.get_param('~linear_d', 0.1)
        self.angular_p = rospy.get_param('~angular_p', 0.5)
        self.angular_d = rospy.get_param('~angular_d', 0.1)
        self.start = rospy.get_param('~start', True)
        self.time_control_get=rospy.get_param('~print_time',False)
        self.first_detect=False
        srv = Server(pidConfig, self.callback_dynamic)
        srv.update_configuration({
        'linear_p': self.linear_p,
        'linear_d': self.linear_d,
        'angular_p': self.angular_p,
        'angular_d': self.angular_d,
        'start': self.start
        })
        self.last_time=rospy.Time.now()
        rospy.spin()
    def callback_dynamic(self,config, level):
        
        rospy.loginfo("""Reconfigure Request: {start},{linear_p}, {linear_d},\ 
        {angular_p}, {angular_d}""".format(**config))
        start_now=config['start']
        self.linear_p=config['linear_p']
        self.linear_d=config['linear_d']
        self.angular_p=config['angular_p']
        self.angular_d=config['angular_d']
        self.finish_docking=not start_now

        return config
        
    def pos_callback(self,msg):
        ar_length=len(msg.markers)
       
        if(self.time_control_get):
            t_now=rospy.Time.now()
            rospy.loginfo("Time callback tracking:{}".format((t_now-self.last_time).to_sec()))
            self.last_time=t_now
        if(ar_length == 0 or self.finish_docking):
            self.speed_cmd=[0,0,0]
            if ar_length == '':
                rospy.loginfo("not see ar_pose")
            if(not self.last_stop):
                self.move()
            self.last_stop=1
            
        else:
            self.ar_pos=msg.markers[0].pose.pose
            
            roll,pitch,yaw=quaternion_to_euler(self.ar_pos.orientation.x,self.ar_pos.orientation.y,self.ar_pos.orientation.z,self.ar_pos.orientation.w)
            # rospy.loginfo("Roll: {:.3f}, Pitch: {:.3f}, Yaw: {:.3f}".format(roll, pitch, yaw))
            # yaw = atan2(2.0*(self.ar_pos.orientation.y*self.ar_pos.orientation.z + self.ar_pos.orientation.w*self.ar_pos.orientation.x), self.ar_pos.orientation.w*self.ar_pos.orientation.w - self.ar_pos.orientation.x*self.ar_pos.orientation.x - self.ar_pos.orientation.y*self.ar_pos.orientation.y + self.ar_pos.orientation.z*self.ar_pos.orientation.z)
            state_robot=[self.ar_pos.position.z,self.ar_pos.position.x,pitch*57.29]
            diff_err=[0,0,0]
            if self.last_stop:
                if(abs(state_robot[2])>12) or abs(state_robot[1])>0.2:
                    self.docking_state=WAIT_TO_Y
                    rospy.loginfo("y state")
                else:
                    self.docking_state=MOVE_ALL_AXIS
                    rospy.loginfo("all state")
      
            diff_err[2]=self.state_target[2]-state_robot[2]
            self.speed_cmd[2]=self.angular_p*diff_err[2]+self.angular_d*(self.last_e[2]-diff_err[2])
            if self.docking_state==MOVE_ALL_AXIS:
                
                for i in range(0,2):
                    diff_err[i]=self.state_target[i]-state_robot[i]
                    self.speed_cmd[i]=self.linear_p*diff_err[i]+self.linear_d*(self.last_e[i]-diff_err[i])
                # diff_err[2]=self.state_target[2]-state_robot[2]
                # self.speed_cmd[2]=self.angular_p*diff_err[2]+self.angular_d*(self.last_e[2]-diff_err[2])
                self.last_e=diff_err
                if abs(diff_err[0])<0.05 and abs(diff_err[2])<1:
                    self.finish_docking=1
                    self.speed_cmd=[0,0,0]
            elif self.docking_state==WAIT_TO_Y:
                diff_err[1]=self.state_target[1]-state_robot[1]
                self.speed_cmd[1]=(self.linear_p*2.6)*diff_err[1]+self.linear_d*1.4*(self.last_e[1]-diff_err[1])
              
                self.last_e=diff_err
                if abs(diff_err[1])<0.2 and abs(diff_err[2])<6:
                    self.docking_state=MOVE_ALL_AXIS
                    rospy.loginfo("yaw state")
          
            self.last_stop=0
            self.move()
            rospy.loginfo("{}".format(state_robot))

    def move(self):
        self.velocity_msg.linear.x = -self.speed_cmd[0]
        self.velocity_msg.linear.y = self.speed_cmd[1]
        self.velocity_msg.angular.z = self.speed_cmd[2]
        
        # rospy.loginfo("x_vel:" + str(self.velocity_msg.linear.x))
        # rospy.loginfo("y_vel :" + str(self.velocity_msg.linear.y))
        # rospy.loginfo("theta_v: " + str(self.velocity_msg.angular.z))
        self.pub.publish(self.velocity_msg)

    def main(self):
        rate=rospy.Rate(10)
    
if __name__=='__main__':
    try:
        robot=Robot_Controller()
    except rospy.ROSInterruptException:
        pass


        

